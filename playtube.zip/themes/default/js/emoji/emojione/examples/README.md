# EmojiOne

## **Project Implementation Examples**

To assist you in getting started with EmojiOne in your project, we've included examples of our core functionalities; primarily Javascript and PHP. Specific examples for other libraries like iOS and Android may be available within their library roots directories.

*See JAVASCIPT.md, PHP.md, and OTHER.md documents within this directory.*

----------

## Demos

You may also want to visit our <a href="https://demos.emojione.com/latest/" target="_blank">Live Demos</a> to see the examples in action.